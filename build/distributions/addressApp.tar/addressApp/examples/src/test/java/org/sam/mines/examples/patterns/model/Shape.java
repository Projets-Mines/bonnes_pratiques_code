package org.sam.mines.examples.patterns.model;

public interface Shape {

    String getName();
}
